#include <bits/stdc++.h>
#include <time.h>
#include "testlib.h"

const int N = 1e6 + 10;

std::vector<int> edges[N];
int dsu[N];

int get(int x) {
  if (x != dsu[x]) dsu[x] = get(dsu[x]);
  return dsu[x];
}

std::pair<int, int> bfs(int n, int u) {
  std::vector<int> dis(n, -1);
  std::vector<int> queue;
  queue.push_back(u);
  dis[u] = 0;
  for (size_t i = 0; i < queue.size(); ++i) {
    int u = queue[i];
    for (size_t j = 0; j < edges[u].size(); ++j) {
      int v = edges[u][j];
      if (dis[v] == -1) {
        dis[v] = dis[u] + 1;
        queue.push_back(v);
      }
    }
  }
  for (int i = 0; i < n; ++i) {
    if (dis[i] > dis[u]) u = i;
  }
  return std::make_pair(u, dis[u]);
}

int main(int argc, char *argv[]) {
  registerTestlibCmd(argc, argv);
  int n = inf.readInt();
  int m = inf.readInt();
  int k = inf.readInt();
  std::string user_ans = ouf.readToken();
  if (user_ans == "NO") quitf(_ok, "ok");
  for (int i = 0; i < n * m; ++i) dsu[i] = i;
  for (int i = 1; i < n * m; ++i) {
    int x1 = ouf.readInt(1, n, "i1") - 1;
    int y1 = ouf.readInt(1, m, "j1") - 1;
    int x2 = ouf.readInt(1, n, "i2") - 1;
    int y2 = ouf.readInt(1, m, "j2") - 1;
    if (abs(x1 - x2) + abs(y1 - y2) != 1) quitf(_wa, "this edge does not exist");
    int u = x1 * m + y1;
    int v = x2 * m + y2;
    if (get(u) == get(v)) quitf(_wa, "input must be a tree");
    dsu[get(u)] = get(v);
    edges[u].push_back(v);
    edges[v].push_back(u);
  }
  std::pair<int, int> x = bfs(n * m, 0);
  std::pair<int, int> y = bfs(n * m, x.first);
  if (y.second != k) quitf(_wa, "expected diameter %d, but %d found", k, y.second);
  quitf(_ok, "ok");
  Sleep(10000);
  return 0;
}
