unit worldline;
interface
uses graderhelperlib;

function query_permutation(n: longint; var ans: array of longint) : longint;

implementation

function query_permutation(n: longint; var ans: array of longint) : longint;
var
	i,j:longint;
begin
	if (n=2) then exit(0);
	new_round;
	addedge(1,2);
	next_step;
	for i:=1 to 3 do
		for j:=i+1 to 3 do
			query(i,j);
	new_round;
	addedge(2,3);
	next_step;
	for i:=1 to 3 do
		for j:=i+1 to 3 do
			query(i,j);
	ans[1]:=2; ans[2]:=1; ans[3]:=3;
	exit(1);
end;
	
end.
