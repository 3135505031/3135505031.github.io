{ This is sample grader for the contestant }
program grader;

uses worldline, graderhelperlib;

var
	n:longint;
	t,i,j:longint;
	A:array[0..10010] of longint;
	ans:array[1..10,0..10010] of longint;
	res:array[1..10,0..4] of longint;
begin
	read(t);
	for i:=1 to t do begin
		grader_init(n,A);
		res[i,2] := query_permutation(n,ans[i]); res[i,0]:=n;
		grader_print(res[i,1],res[i,3],res[i,4]);
		if (res[i,2]=0) then 
			for j:=1 to n do ans[i,j]:=0;
	end;
	writeln('a09502fbf6338bf3d12ae8e21e7ca90f');
	for i:=1 to t do begin
		writeln(res[i,1],' ',res[i,2],' ',res[i,3],' ',res[i,4]);
		for j:=1 to res[i,0] do write(ans[i,j],' '); writeln;
	end;
end.
