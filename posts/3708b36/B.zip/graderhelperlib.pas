{$mode objfpc}
{$m+}

unit graderhelperlib;
interface

procedure new_round();
procedure next_step();
procedure addedge(u,v:longint);
function query(u,v:longint):longint;

procedure grader_init(var out_n:longint; var out_A:array of longint);
procedure grader_print(var fla,tot_q,tot_a:longint);

implementation

var
	n,turn,step:longint;
	father,height:array[0..20010] of longint;
	A:array[0..10010] of longint;
	tot_query,tot_addedge,flag:longint;

procedure grader_init(var out_n:longint;var out_A:array of longint);
var
	i:longint;
begin
	read(n); out_n:=n; tot_query:=0; tot_addedge:=0; flag:=1; turn:=0; step:=0;
	for i:=1 to n do read(A[i]);
	for i:=1 to n do out_A[i]:=A[i];
end;

procedure grader_print(var fla,tot_q,tot_a:longint);
var
	i:longint;
begin
	fla:=flag; tot_q:=tot_query; tot_a:=tot_addedge;
end;

procedure next_step();
begin
	if (step<>1) then flag:=0;
	inc(step);
end;

function findfather(k:longint):longint;
begin
	if (k=father[k]) then exit(k);
	father[k]:=findfather(father[k]); exit(father[k]);
end;

procedure link(u,v:longint);
var
	t:longint;
begin
	u:=findfather(u); v:=findfather(v);
	if (u<>v) then begin
		if (height[u]<height[v]) then begin
			t:=u; u:=v; v:=t;
		end;
		father[v]:=u; 
		if (height[u]=height[v]) then inc(height[u]);
	end;
end;
	
procedure addedge(u,v:longint);
var
	t:longint;
begin
	if (step<>1) then flag:=0; inc(tot_addedge);
	if (u<=0) or (u>n) or (v<=0) or (v>n) then exit;
	link(u,v);
end;

function query(u,v:longint):longint;
begin
	if (step<>2) then flag:=0; inc(tot_query);
	if (u<=0) or (u>n) or (v<=0) or (v>n) then exit;
	u:=u+n; v:=v+n;
	u:=findfather(u); v:=findfather(v);
	if (u=v) then exit(1) else exit(0);
end;

procedure new_round();
var
	i:longint;
begin
	if (turn=2) or ((step<>2) and (turn>0)) then flag:=0;
	inc(turn); step:=1;
	for i:=1 to n+n do begin
		father[i]:=i; height[i]:=1;
	end;
	for i:=1 to n do link(i,A[i]+n);
end;

end.
