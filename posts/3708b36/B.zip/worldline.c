#include "worldline.h"

int query_permutation(int n,int ans[])
{
	if (n==2) return 0;
	new_round();
	addedge(1,2);
	next_step();
	int i,j;
	for (i=1;i<=3;i++)
		for (j=i+1;j<=3;j++) query(i,j);
	new_round();
	addedge(2,3);
	next_step();
	for (i=1;i<=3;i++)
		for (j=i+1;j<=3;j++) query(i,j);
	ans[1]=2; ans[2]=1; ans[3]=3;
	return 1;
}
